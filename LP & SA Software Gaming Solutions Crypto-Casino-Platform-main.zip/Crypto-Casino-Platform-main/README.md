## Crypto Casino Platform

This application is for everyone (be it individual entrepreneurs or small organizations) who wants to quickly start their own online gaming business, but doesn’t have time and / or sufficient funds to develop a tailor made solution or buy expensive casino software packages from other vendors.

